# Auto-resume Test Task

Create a simple TypeScript file for testing auto-resume behavior.

## Requirements

1. Create `src/auto-resume-test.ts` with a simple function
2. The function should be named `testAutoResume`
3. Return a string "auto-resume works"

## Expected Output

```typescript
export function testAutoResume(): string {
  return "auto-resume works";
}
```
