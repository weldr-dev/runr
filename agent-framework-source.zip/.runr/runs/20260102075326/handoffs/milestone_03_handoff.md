Updated CLI help text for `runr init` command with clearer flag descriptions. Added --interactive flag handling that displays a stub message explaining the feature is planned for a future release. All flags now have descriptive help text explaining their purpose:

- --repo: 'Path to repository (defaults to current directory)'
- --interactive: 'Launch interactive setup wizard to configure verification commands'
- --print: 'Display generated config in terminal without writing to disk'
- --force: 'Overwrite existing .runr/runr.config.json if present'

When --interactive is used, users see a message directing them to use the automatic config generation and manual editing workflow for now.