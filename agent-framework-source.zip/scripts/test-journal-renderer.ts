#!/usr/bin/env tsx
/**
 * Dev script to test journal renderer on real journal data
 *
 * Usage: tsx scripts/test-journal-renderer.ts <journal_json_path>
 */

import fs from 'node:fs';
import { renderJournal } from '../src/journal/renderer.js';
import type { JournalJson } from '../src/journal/types.js';

const args = process.argv.slice(2);
const jsonPath = args[0] || '/tmp/journal-test-fixed.json';

if (!fs.existsSync(jsonPath)) {
  console.error(`ERROR: Journal file not found: ${jsonPath}`);
  process.exit(1);
}

try {
  const journal: JournalJson = JSON.parse(fs.readFileSync(jsonPath, 'utf-8'));
  const markdown = renderJournal(journal);
  console.log(markdown);
} catch (err) {
  console.error('ERROR:', err);
  process.exit(1);
}
