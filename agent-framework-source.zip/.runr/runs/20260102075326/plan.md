{
  "milestones": [
    {
      "goal": "Add Python project detection logic to init command",
      "files_expected": [
        "src/commands/init.ts"
      ],
      "done_checks": [
        "Function detectPythonVerification exists and checks for pytest.ini, pyproject.toml, poetry.lock",
        "Python verification commands (pytest, poetry) are added to appropriate tiers",
        "Python presets (pytest, poetry) are detected from pyproject.toml",
        "Detection falls back to package.json if no Python markers found"
      ],
      "risk_level": "medium"
    },
    {
      "goal": "Improve messaging when no verification commands are detected",
      "files_expected": [
        "src/commands/init.ts"
      ],
      "done_checks": [
        "When no verification found, clear message suggests editing config or using --interactive",
        "Message differentiates between 'no package.json' and 'empty package.json scripts'",
        "Output includes actionable next steps with specific file paths"
      ],
      "risk_level": "low"
    },
    {
      "goal": "Update CLI help text and add --interactive flag handling",
      "files_expected": [
        "src/cli.ts",
        "src/commands/init.ts"
      ],
      "done_checks": [
        "runr init --help shows improved descriptions for all flags",
        "Flag descriptions explain what each option does clearly",
        "--interactive flag is present in CLI definition (already exists, verify wording)",
        "When --interactive is used, shows stub message indicating feature is planned"
      ],
      "risk_level": "low"
    },
    {
      "goal": "Test Python detection and verify all existing functionality",
      "files_expected": [
        "tests/commands/init.test.ts",
        "dogfood/test-python-detection.md"
      ],
      "done_checks": [
        "Manual test: runr init --print on minimal Python repo shows pytest in verification",
        "Manual test: runr init on empty repo shows helpful message",
        "npm run build succeeds with no errors",
        "npm test passes all existing tests",
        "Existing Node/TypeScript detection still works correctly"
      ],
      "risk_level": "medium"
    }
  ],
  "risk_map": [
    "Risk 1: Python detection might interfere with Node detection - mitigate by testing both sequentially and ensuring fallback",
    "Risk 2: Missing edge cases in Python ecosystem (pip, setuptools, tox) - scope limited to pytest/poetry/pyproject.toml only",
    "Risk 3: No existing test coverage for init command - rely on manual testing and npm test for regression"
  ],
  "do_not_touch": [
    "src/commands/run.ts",
    "src/commands/orchestrate.ts",
    "src/supervisor/**",
    "src/orchestrator/**"
  ]
}