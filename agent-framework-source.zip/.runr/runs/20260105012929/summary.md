# Summary

Run stopped due to guard violations.

Guard Failure Details:

Reasons:
  - dirty_worktree

Scope violations:
  - None

Lockfile violations:
  - None

Dirty files (env noise excluded):
  - docs/architecture/
  - docs/sprints/

Binary checks:
- claude: 2.0.76 (Claude Code)
- codex: codex-cli 0.77.0

Ping results:
  - claude: OK (7674ms)
  - codex: OK (2277ms)