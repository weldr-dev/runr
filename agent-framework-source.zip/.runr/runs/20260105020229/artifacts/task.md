# Fix Chess Rule Enforcement

## Goal
Fix the chess game at dogfood/chess-game to properly enforce all chess rules and prevent illegal moves.

## Scope
owns:
  - dogfood/chess-game/src/**

## Requirements
- Prevent all illegal piece movements
- Enforce check/checkmate rules (cannot move into check)
- Enforce turn-based gameplay strictly
- Fix castling validation (king/rook not moved, no pieces between, not through check)
- Fix en passant validation
- Fix pawn promotion validation
- Prevent moving opponent's pieces
- Prevent moving when in checkmate/stalemate

## Success Criteria
- Cannot make illegal moves (each piece type respects its movement rules)
- Cannot move into check
- Cannot castle illegally
- Game correctly detects and prevents moves when in check
- Manual testing confirms all major illegal moves are blocked
- Build passes (`npm run build` in chess-game directory)

## Verification
tier0: cd dogfood/chess-game && npm run build

## Notes
- The chess game is in `dogfood/chess-game`
- Focus on `dogfood/chess-game/src/logic/moveValidation.ts` and `dogfood/chess-game/src/logic/gameState.ts`
- The UI drag-and-drop should be blocked if move is invalid
- Need to validate moves BEFORE applying them to state
