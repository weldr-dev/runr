#!/usr/bin/env bash
# Simple verification script - always passes
echo "PASS: verification passed" >&2
exit 0
