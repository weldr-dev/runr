# Collision Test Task A

Modify `src/shared/collision.ts` to add function A.

## Requirements

1. Create or modify `src/shared/collision.ts`
2. Add a function named `functionA`
3. The function should return "A"

## Expected Output

```typescript
export function functionA(): string {
  return "A";
}
```
