# Chess Game - Full 2-Player Implementation

## Objective
Build a complete, fully functional 2-player chess game in ../chess-game with React + TypeScript featuring:
- Complete chess rules (moves, captures, castling, en passant, pawn promotion, checkmate, stalemate)
- Modern/minimalist UI with smooth animations
- Move validation with visual highlighting
- Move history display in algebraic notation
- Game timer/clock with configurable time controls
- Undo/Redo functionality
- Responsive design

## Scope
owns:
  - ../chess-game/**

denylist:
  - "**/node_modules/**"
  - "**/.git/**"
  - "**/dist/**"

## Milestones

### 1. Project Setup
- [ ] Create ../chess-game directory with Vite + React + TypeScript
- [ ] Set up project structure (src/components, src/logic, src/types, src/styles)
- [ ] Install dependencies (React, TypeScript, Vite)
- [ ] Create base TypeScript types for chess pieces, board, positions, moves
- [ ] Set up development environment with hot reload
- [ ] Verify project builds successfully

### 2. Core Chess Logic
- [ ] Implement board state representation (8x8 grid)
- [ ] Implement piece movement rules for all pieces (Pawn, Rook, Knight, Bishop, Queen, King)
- [ ] Add move validation logic (check if move is legal)
- [ ] Implement check detection
- [ ] Implement checkmate and stalemate detection
- [ ] Add special moves: castling (kingside and queenside)
- [ ] Add special moves: en passant
- [ ] Add special moves: pawn promotion
- [ ] Create game state manager with turn tracking
- [ ] Verify all chess rules work correctly with unit tests

### 3. Board and Piece UI
- [ ] Create Board component with 8x8 grid
- [ ] Create Square component with alternating colors
- [ ] Create Piece component with chess piece rendering (use Unicode chess symbols or SVG)
- [ ] Implement drag-and-drop or click-to-move interaction
- [ ] Add piece selection highlighting
- [ ] Add valid move highlighting when piece is selected
- [ ] Implement smooth CSS animations for piece movements
- [ ] Apply modern/minimalist styling with clean aesthetics
- [ ] Make board responsive for different screen sizes
- [ ] Verify pieces render correctly and can be moved

### 4. Game Features
- [ ] Create MoveHistory component displaying moves in algebraic notation
- [ ] Implement algebraic notation converter (e.g., "e4", "Nf3", "O-O")
- [ ] Create GameTimer component with countdown clocks for both players
- [ ] Add configurable time controls (e.g., 10+0, 5+3, custom)
- [ ] Implement timer pause/resume on move
- [ ] Add Undo button with move history rollback
- [ ] Add Redo button to restore undone moves
- [ ] Create game status display (check, checkmate, stalemate, current turn)
- [ ] Add pawn promotion UI (modal or popup to select piece)
- [ ] Verify all features work correctly together

### 5. Polish and Final Integration
- [ ] Add New Game button to reset the board
- [ ] Implement game settings panel (timer config, board theme)
- [ ] Add visual feedback for check situations
- [ ] Add sound effects or visual cues for captures (optional, simple)
- [ ] Polish animations and transitions
- [ ] Ensure responsive design works on mobile/tablet
- [ ] Add README with instructions to run and play
- [ ] Final testing of all game scenarios (checkmate, stalemate, draws)
- [ ] Code cleanup and optimization
- [ ] Verify complete game is playable end-to-end

## Verification

tier0: npm run build
tier1: npm run dev -- --help || echo "Dev server configured"
tier2: npm run build && npm run preview

## Context

### Technical Architecture
- **React**: Component-based UI with hooks for state management
- **TypeScript**: Strong typing for chess logic, pieces, and game state
- **Vite**: Fast build tool and dev server
- **CSS Modules or Styled Components**: For component styling

### Chess Piece Representation
Use Unicode chess symbols or simple SVG icons:
- White: ♔ ♕ ♖ ♗ ♘ ♙ (King, Queen, Rook, Bishop, Knight, Pawn)
- Black: ♚ ♛ ♜ ♝ ♞ ♟

### Key Files Structure
```
chess-game/
├── src/
│   ├── components/
│   │   ├── Board.tsx
│   │   ├── Square.tsx
│   │   ├── Piece.tsx
│   │   ├── MoveHistory.tsx
│   │   ├── GameTimer.tsx
│   │   └── GameControls.tsx
│   ├── logic/
│   │   ├── gameState.ts
│   │   ├── moveValidation.ts
│   │   ├── checkDetection.ts
│   │   └── algebraicNotation.ts
│   ├── types/
│   │   └── chess.ts
│   ├── App.tsx
│   └── main.tsx
├── package.json
├── vite.config.ts
└── tsconfig.json
```

### Special Rules to Implement
1. **Castling**: King and rook must not have moved, no pieces between them, king not in/through check
2. **En Passant**: Pawn captures diagonally on same rank after opponent's pawn advances two squares
3. **Pawn Promotion**: Pawn reaching opposite end promotes to Queen/Rook/Bishop/Knight
4. **Check**: King is under attack
5. **Checkmate**: King in check with no legal moves
6. **Stalemate**: No legal moves but king not in check

### UI/UX Considerations
- Clear visual distinction between white and black pieces
- Smooth animations when pieces move (200-300ms transitions)
- Highlighted squares for selected piece and valid moves
- Clear indication of whose turn it is
- Timer displays for both players
- Move history scrollable if game is long
- Responsive design: board scales to fit screen
