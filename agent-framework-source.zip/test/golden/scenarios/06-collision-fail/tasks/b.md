# Collision Test Task B

Modify `src/shared/collision.ts` to add function B.

## Requirements

1. Create or modify `src/shared/collision.ts`
2. Add a function named `functionB`
3. The function should return "B"

## Expected Output

```typescript
export function functionB(): string {
  return "B";
}
```
