# Add API endpoint

Add a simple health check endpoint to the API module.
