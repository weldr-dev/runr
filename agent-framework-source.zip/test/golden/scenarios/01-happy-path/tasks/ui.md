# Add greeting function

Add a `greet(name: string)` function to the UI module that returns a greeting message.
