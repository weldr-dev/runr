{
  "milestones": [
    {
      "goal": "Create core chess data structures and piece movement rules for each piece type",
      "files_expected": [
        "dogfood/chess-game/src/types.ts",
        "dogfood/chess-game/src/logic/pieceMovement.ts",
        "dogfood/chess-game/package.json",
        "dogfood/chess-game/tsconfig.json"
      ],
      "done_checks": [
        "Types define all chess pieces, colors, positions, and game state",
        "Each piece type has movement validation (pawn, knight, bishop, rook, queen, king)",
        "Movement rules account for piece-specific constraints (pawn forward-only, knight L-shape, etc.)",
        "Build passes with npm run build"
      ],
      "risk_level": "low"
    },
    {
      "goal": "Implement move validation with path checking and turn enforcement",
      "files_expected": [
        "dogfood/chess-game/src/logic/moveValidation.ts",
        "dogfood/chess-game/src/logic/pathChecking.ts"
      ],
      "done_checks": [
        "Validates piece ownership matches current turn",
        "Checks path is clear for sliding pieces (bishop, rook, queen)",
        "Prevents capturing own pieces",
        "Validates destination is within board bounds",
        "Returns detailed validation results with error messages"
      ],
      "risk_level": "medium"
    },
    {
      "goal": "Implement check detection and enforce cannot-move-into-check rule",
      "files_expected": [
        "dogfood/chess-game/src/logic/checkDetection.ts",
        "dogfood/chess-game/src/logic/moveValidation.ts"
      ],
      "done_checks": [
        "Detects when king is under attack",
        "Simulates moves and validates king safety before allowing move",
        "Prevents moves that would expose own king to check",
        "Correctly identifies checking pieces",
        "Build passes with npm run build"
      ],
      "risk_level": "high"
    },
    {
      "goal": "Implement special moves: castling, en passant, and pawn promotion",
      "files_expected": [
        "dogfood/chess-game/src/logic/specialMoves.ts",
        "dogfood/chess-game/src/logic/moveValidation.ts"
      ],
      "done_checks": [
        "Castling validates king and rook haven't moved, path is clear, and not castling through check",
        "En passant validates pawn position and previous move was two-square pawn advance",
        "Pawn promotion triggers when pawn reaches opposite end",
        "All special move validations integrated into main move validation"
      ],
      "risk_level": "high"
    },
    {
      "goal": "Implement game state management with checkmate and stalemate detection",
      "files_expected": [
        "dogfood/chess-game/src/logic/gameState.ts",
        "dogfood/chess-game/src/logic/gameEndDetection.ts"
      ],
      "done_checks": [
        "Tracks move history for castling and en passant validation",
        "Detects checkmate (in check with no legal moves)",
        "Detects stalemate (not in check but no legal moves)",
        "Prevents any moves after game ends",
        "Game state transitions are immutable"
      ],
      "risk_level": "medium"
    },
    {
      "goal": "Create UI with drag-and-drop that enforces all validation rules",
      "files_expected": [
        "dogfood/chess-game/src/components/ChessBoard.tsx",
        "dogfood/chess-game/src/components/ChessPiece.tsx",
        "dogfood/chess-game/src/App.tsx",
        "dogfood/chess-game/src/index.tsx"
      ],
      "done_checks": [
        "Drag-and-drop only allows legal moves",
        "UI shows check/checkmate/stalemate status",
        "Turn indicator shows current player",
        "Move is validated before state update",
        "npm run build succeeds in dogfood/chess-game"
      ],
      "risk_level": "medium"
    }
  ],
  "risk_map": [
    "Check detection complexity: Must simulate all opponent pieces to detect attacks on king",
    "Castling through check: Need to validate all squares king passes through are safe",
    "En passant timing: Must track previous move to validate en passant eligibility",
    "Move simulation: Creating temporary board states for validation without mutating actual state",
    "UI synchronization: Ensuring drag-and-drop respects async validation results"
  ],
  "do_not_touch": []
}