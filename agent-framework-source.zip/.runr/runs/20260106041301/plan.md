{
  "milestones": [
    {
      "goal": "Add v0.6.0 section to CHANGELOG.md documenting Meta-Agent UX Sprint features",
      "files_expected": [
        "CHANGELOG.md"
      ],
      "done_checks": [
        "CHANGELOG.md has new v0.6.0 section under [Unreleased]",
        "All four major features documented: runr meta, --with-claude, .claude/ templates, enhanced doctor",
        "Format matches existing changelog style (Keep a Changelog format)",
        "No typos or formatting errors",
        "Version comparison links updated"
      ],
      "risk_level": "low"
    }
  ],
  "risk_map": [
    "Low risk: Single file modification with clear existing format to follow",
    "Mitigation: Review existing entries to match tone and structure"
  ],
  "do_not_touch": [
    "package.json",
    "src/**",
    "docs/**",
    "packs/**"
  ]
}