Successfully implemented special chess moves (castling, en passant, pawn promotion) in dogfood/chess-game/src/logic/specialMoves.ts and integrated them into moveValidation.ts.

Implementation details:
- Castling: Validates king/rook haven't moved, path is clear, not in/through/into check (lines 19-124)
- En passant: Validates pawn diagonal to empty square, enemy pawn adjacent, last move was 2-square pawn advance (lines 129-204)
- Pawn promotion: Triggers when pawn reaches opposite end row (lines 209-219)
- Integration: Special moves validated before normal piece movement in validateMove() (moveValidation.ts:58-70)

The test failure in apps/deckbuilder/src/components/Board.test.tsx is a pre-existing issue (confirmed by testing without my changes) - it cannot find 'react/jsx-dev-runtime'. This is unrelated to the chess game implementation. The chess game itself builds successfully with no TypeScript errors.