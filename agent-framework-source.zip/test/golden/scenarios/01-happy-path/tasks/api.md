# Add getUsers count function

Add a `getUserCount()` function to the API module that returns the count of users.
