# Update shared User interface for API

Add an `email` field to the User interface in shared.ts and update the API to use it.
