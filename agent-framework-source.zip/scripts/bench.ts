#!/usr/bin/env npx ts-node
/**
 * Benchmark Harness for Agent Runner Validation
 *
 * Runs a matrix of scenarios and produces a summary table for analysis.
 * Designed for repeatability and A/B testing (e.g., context pack on/off).
 *
 * Usage:
 *   npx ts-node scripts/bench.ts [--dry-run] [--scenario <name>] [--output <path>]
 *
 * Examples:
 *   npx ts-node scripts/bench.ts                     # Run all scenarios
 *   npx ts-node scripts/bench.ts --dry-run           # Preview without executing
 *   npx ts-node scripts/bench.ts --scenario noop     # Run single scenario
 *   npx ts-node scripts/bench.ts --output results.md # Custom output path
 */

import { spawn, ChildProcess } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

// ============================================================================
// Types
// ============================================================================

interface BenchScenario {
  /** Unique identifier for this scenario */
  name: string;
  /** Path to task file (relative to project root) */
  task: string;
  /** Path to target repo */
  repo: string;
  /** Time budget in minutes */
  time: number;
  /** Max ticks */
  maxTicks: number;
  /** Enable worktree isolation */
  worktree: boolean;
  /** Path to agent config file (relative to project root) */
  config?: string;
  /** Environment variables to set (e.g., CONTEXT_PACK=1) */
  env?: Record<string, string>;
  /** Additional CLI flags */
  flags?: string[];
}

interface BenchResult {
  scenario: string;
  runId: string | null;
  outcome: string;
  stopReason: string | null;
  durationSeconds: number | null;
  milestonesCompleted: number;
  milestonesTotal: number | null;
  workerClaude: number | string;
  workerCodex: number | string;
  verifyAttempts: number;
  verifyRetries: number;
  verifyDurationSeconds: number;
  infraRetries: number;
  fallbackCount: number;
  stallsTriggered: number;
  maxTicksHit: boolean;
  ticksUsed: number;
  diagnosis?: {
    primary: string;
    confidence: number;
    nextAction?: string;
  };
  error?: string;
}

interface SummaryJson {
  run_id: string;
  outcome: 'complete' | 'stopped' | 'running' | 'unknown';
  stop_reason: string | null;
  duration_seconds: number | null;
  milestones: { completed: number; total: number | null };
  worker_calls: { claude: number | 'unknown'; codex: number | 'unknown' };
  verification: { attempts: number; retries: number; duration_seconds: number };
  reliability: {
    infra_retries: number;
    fallback_used: boolean;
    fallback_count: number;
    stalls_triggered: number;
    late_results_ignored: number;
    max_ticks_hit: boolean;
    ticks_used: number;
  };
  config: {
    dry_run: boolean | null;
    worktree_enabled: boolean;
    time_budget_minutes: number | null;
    max_ticks: number | null;
  };
  timestamps: { started_at: string | null; ended_at: string | null };
  diagnosis?: {
    primary: string;
    confidence: number;
    next_action?: string;
  };
}

// ============================================================================
// Scenario Presets
// ============================================================================

/**
 * MINIMAL preset: Quick infrastructure validation (2 scenarios)
 * Purpose: Verify the harness and agent boot chain work
 * Expected time: ~10 minutes total
 */
const PRESET_MINIMAL: BenchScenario[] = [
  {
    name: 'noop-worktree',
    task: 'tasks/noop.md',
    repo: 'apps/tactical-grid',
    time: 5,
    maxTicks: 10,
    worktree: true,
  },
  {
    name: 'noop-no-worktree',
    task: 'tasks/noop.md',
    repo: 'apps/tactical-grid',
    time: 5,
    maxTicks: 10,
    worktree: false,
  },
];

/**
 * CONTEXT_PACK preset: A/B test for context pack effectiveness
 * Purpose: Measure if context pack reduces worker churn
 * Expected time: ~60 minutes total
 */
const PRESET_CONTEXT_AB: BenchScenario[] = [
  {
    name: 'engine-bootstrap-ctx-off',
    task: 'tasks/tactical-grid/001_engine_bootstrap.md',
    repo: 'apps/tactical-grid',
    config: 'tasks/tactical-grid/agent.config.json',
    time: 30,
    maxTicks: 50,
    worktree: true,
    env: { CONTEXT_PACK: '0' },
  },
  {
    name: 'engine-bootstrap-ctx-on',
    task: 'tasks/tactical-grid/001_engine_bootstrap.md',
    repo: 'apps/tactical-grid',
    config: 'tasks/tactical-grid/agent.config.json',
    time: 30,
    maxTicks: 50,
    worktree: true,
    env: { CONTEXT_PACK: '1' },
  },
];

/**
 * STRESS preset: Diagnostic runs to find failure modes
 * Purpose: Stress test verification, IMPLEMENT cycles, infrastructure
 * Expected time: ~60 minutes total
 */
const PRESET_STRESS: BenchScenario[] = [
  // Pure verification/cwd stress: lint/typecheck/tests on an existing package
  {
    name: 'verify-stress-deckbuilder',
    task: 'tasks/deckbuilder/007_visual_tests.md',
    repo: 'apps/deckbuilder',
    time: 20,
    maxTicks: 30,
    worktree: true,
  },
  // Multi-milestone IMPLEMENT churn: complex task with many milestones
  {
    name: 'impl-churn-engine',
    task: 'tasks/tactical-grid/001_engine_bootstrap.md',
    repo: 'apps/tactical-grid',
    time: 30,
    maxTicks: 40,
    worktree: true,
  },
  // Quick verification: noop with strict ticks
  {
    name: 'noop-strict',
    task: 'tasks/noop.md',
    repo: 'apps/tactical-grid',
    time: 3,
    maxTicks: 5,
    worktree: true,
  },
];

/**
 * FULL preset: Complete 10-run validation matrix
 * Purpose: Comprehensive validation before any major change
 * Expected time: ~2 hours total
 */
const PRESET_FULL: BenchScenario[] = [
  // Noop baseline (2 runs)
  ...PRESET_MINIMAL,
  // Context pack A/B (2 runs)
  ...PRESET_CONTEXT_AB,
  // Stress tests (3 runs)
  ...PRESET_STRESS,
  // Additional variation runs
  {
    name: 'engine-short-budget',
    task: 'tasks/tactical-grid/001_engine_bootstrap.md',
    repo: 'apps/tactical-grid',
    time: 10,
    maxTicks: 15,
    worktree: true,
  },
  {
    name: 'noop-high-ticks',
    task: 'tasks/noop.md',
    repo: 'apps/tactical-grid',
    time: 5,
    maxTicks: 50,
    worktree: true,
  },
  {
    name: 'engine-no-worktree',
    task: 'tasks/tactical-grid/001_engine_bootstrap.md',
    repo: 'apps/tactical-grid',
    time: 15,
    maxTicks: 25,
    worktree: false,
  },
];

const PRESETS: Record<string, BenchScenario[]> = {
  minimal: PRESET_MINIMAL,
  context: PRESET_CONTEXT_AB,
  stress: PRESET_STRESS,
  full: PRESET_FULL,
};

const DEFAULT_SCENARIOS = PRESET_MINIMAL;

// ============================================================================
// CLI Argument Parsing
// ============================================================================

interface BenchOptions {
  dryRun: boolean;
  scenarioFilter: string | null;
  outputPath: string;
  parallel: boolean;
  preset: string | null;
  configPath: string | null;
  repeat: number;
}

function parseArgs(): BenchOptions {
  const args = process.argv.slice(2);
  const options: BenchOptions = {
    dryRun: false,
    scenarioFilter: null,
    outputPath: 'bench-results.md',
    parallel: false,
    preset: null,
    configPath: null,
    repeat: 1,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--dry-run') {
      options.dryRun = true;
    } else if (arg === '--scenario' && args[i + 1]) {
      options.scenarioFilter = args[++i];
    } else if (arg === '--output' && args[i + 1]) {
      options.outputPath = args[++i];
    } else if (arg === '--parallel') {
      options.parallel = true;
    } else if (arg === '--preset' && args[i + 1]) {
      options.preset = args[++i];
    } else if (arg === '--config' && args[i + 1]) {
      options.configPath = args[++i];
    } else if (arg === '--repeat' && args[i + 1]) {
      options.repeat = parseInt(args[++i], 10) || 1;
    } else if (arg === '--help' || arg === '-h') {
      printUsage();
      process.exit(0);
    }
  }

  return options;
}

function printUsage(): void {
  console.log(`
Benchmark Harness for Agent Runner Validation

Usage:
  npx ts-node scripts/bench.ts [options]

Options:
  --dry-run           Preview scenarios without executing
  --preset <name>     Use a preset: minimal, context, stress, full
  --scenario <name>   Run only scenarios matching this name
  --config <path>     Load scenarios from JSON config file
  --repeat <n>        Repeat each scenario n times (for variance analysis)
  --output <path>     Output file path (default: bench-results.md)
  --parallel          Run scenarios in parallel (experimental)
  --help, -h          Show this help message

Presets:
  minimal   Quick infrastructure validation (2 scenarios, ~10 min)
  context   Context pack A/B test (2 scenarios, ~30 min)
  stress    Diagnostic stress tests (3 scenarios, ~60 min)
  full      Complete 10-run validation matrix (~2 hours)

Examples:
  npx ts-node scripts/bench.ts                     # Run minimal preset
  npx ts-node scripts/bench.ts --dry-run           # Preview minimal preset
  npx ts-node scripts/bench.ts --preset full       # Run full validation
  npx ts-node scripts/bench.ts --preset context    # Context pack A/B only
  npx ts-node scripts/bench.ts --scenario noop     # Filter by name
  npx ts-node scripts/bench.ts --repeat 3          # Run each scenario 3x

Config file format (JSON):
  {
    "scenarios": [
      { "name": "my-test", "task": "tasks/foo.md", "repo": "apps/bar",
        "time": 10, "maxTicks": 20, "worktree": true }
    ]
  }
`);
}

// ============================================================================
// Scenario Execution
// ============================================================================

async function runScenario(
  scenario: BenchScenario,
  dryRun: boolean
): Promise<BenchResult> {
  const baseResult: BenchResult = {
    scenario: scenario.name,
    runId: null,
    outcome: 'unknown',
    stopReason: null,
    durationSeconds: null,
    milestonesCompleted: 0,
    milestonesTotal: null,
    workerClaude: 'unknown',
    workerCodex: 'unknown',
    verifyAttempts: 0,
    verifyRetries: 0,
    verifyDurationSeconds: 0,
    infraRetries: 0,
    fallbackCount: 0,
    stallsTriggered: 0,
    maxTicksHit: false,
    ticksUsed: 0,
  };

  // Validate tier0 configuration before running
  const tier0Validation = validateTier0Config(scenario);
  if (tier0Validation.warnings.length > 0) {
    console.log(`\n⚠️  Config warnings for ${scenario.name}:`);
    for (const warn of tier0Validation.warnings) {
      console.log(`   - ${warn}`);
    }
    if (!tier0Validation.ok) {
      console.log(`   tier0 commands: [${tier0Validation.tier0Commands.join(', ')}]`);
      console.log(`\n❌ SKIPPING ${scenario.name}: tier0 incomplete (fix config before benchmarking)`);
      return {
        ...baseResult,
        outcome: 'skipped',
        error: `tier0 incomplete: ${tier0Validation.warnings.join('; ')}`,
      };
    }
  }

  if (dryRun) {
    console.log(`[DRY-RUN] Would run scenario: ${scenario.name}`);
    console.log(`  Task: ${scenario.task}`);
    console.log(`  Repo: ${scenario.repo}`);
    console.log(`  Time: ${scenario.time}m, MaxTicks: ${scenario.maxTicks}`);
    console.log(`  Worktree: ${scenario.worktree}`);
    console.log(`  tier0: [${tier0Validation.tier0Commands.join(', ')}]`);
    if (scenario.env) {
      console.log(`  Env: ${JSON.stringify(scenario.env)}`);
    }
    return { ...baseResult, outcome: 'dry-run' };
  }

  console.log(`\n${'='.repeat(60)}`);
  console.log(`Running scenario: ${scenario.name}`);
  console.log(`${'='.repeat(60)}`);

  try {
    // Build CLI command
    const cliArgs = [
      'dist/cli.js',
      'run',
      '--repo',
      scenario.repo,
      '--task',
      scenario.task,
      '--time',
      String(scenario.time),
      '--max-ticks',
      String(scenario.maxTicks),
      '--skip-doctor', // Skip doctor for batch runs
    ];

    if (scenario.worktree) {
      cliArgs.push('--worktree');
    }

    if (scenario.config) {
      cliArgs.push('--config', scenario.config);
    }

    if (scenario.flags) {
      cliArgs.push(...scenario.flags);
    }

    // Prepare environment
    const env = { ...process.env, ...scenario.env };

    console.log(`Command: node ${cliArgs.join(' ')}`);

    // Execute run
    const runResult = await executeCommand('node', cliArgs, { env });

    // Extract run ID from output (look for "run_id=YYYYMMDDHHMMSS" or "Run ID: YYYYMMDDHHMMSS")
    const runIdMatch = runResult.stdout.match(/run_id=(\d{14})/) ||
                       runResult.stdout.match(/Run ID:\s*(\d{14})/);
    const runId = runIdMatch ? runIdMatch[1] : null;

    if (!runId) {
      console.error('Could not extract run ID from output');
      return { ...baseResult, error: 'No run ID in output' };
    }

    baseResult.runId = runId;
    console.log(`Run ID: ${runId}`);

    // Generate summary
    await executeCommand('node', ['dist/cli.js', 'summarize', runId]);

    // Read summary.json
    const summaryPath = path.join('runs', runId, 'summary.json');
    if (fs.existsSync(summaryPath)) {
      const summary = JSON.parse(
        fs.readFileSync(summaryPath, 'utf-8')
      ) as SummaryJson;
      return summaryToResult(scenario.name, summary);
    } else {
      console.error(`Summary not found: ${summaryPath}`);
      return { ...baseResult, error: 'Summary not generated' };
    }
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    console.error(`Scenario failed: ${errorMsg}`);
    return { ...baseResult, error: errorMsg };
  }
}

function summaryToResult(scenarioName: string, summary: SummaryJson): BenchResult {
  return {
    scenario: scenarioName,
    runId: summary.run_id,
    outcome: summary.outcome,
    stopReason: summary.stop_reason,
    durationSeconds: summary.duration_seconds,
    milestonesCompleted: summary.milestones.completed,
    milestonesTotal: summary.milestones.total,
    workerClaude: summary.worker_calls.claude,
    workerCodex: summary.worker_calls.codex,
    verifyAttempts: summary.verification.attempts,
    verifyRetries: summary.verification.retries,
    verifyDurationSeconds: summary.verification.duration_seconds,
    infraRetries: summary.reliability.infra_retries,
    fallbackCount: summary.reliability.fallback_count,
    stallsTriggered: summary.reliability.stalls_triggered,
    maxTicksHit: summary.reliability.max_ticks_hit,
    ticksUsed: summary.reliability.ticks_used,
    diagnosis: summary.diagnosis
      ? {
          primary: summary.diagnosis.primary,
          confidence: summary.diagnosis.confidence,
          nextAction: summary.diagnosis.next_action,
        }
      : undefined,
  };
}

interface CommandResult {
  stdout: string;
  stderr: string;
  exitCode: number;
}

function executeCommand(
  command: string,
  args: string[],
  options?: { env?: NodeJS.ProcessEnv; timeout?: number }
): Promise<CommandResult> {
  return new Promise((resolve, reject) => {
    const proc = spawn(command, args, {
      env: options?.env ?? process.env,
      cwd: process.cwd(),
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    let stdout = '';
    let stderr = '';

    proc.stdout.on('data', (data: Buffer) => {
      const text = data.toString();
      stdout += text;
      process.stdout.write(text); // Stream to console
    });

    proc.stderr.on('data', (data: Buffer) => {
      const text = data.toString();
      stderr += text;
      process.stderr.write(text); // Stream to console
    });

    const timeout = options?.timeout ?? 30 * 60 * 1000; // 30 min default
    const timer = setTimeout(() => {
      proc.kill('SIGTERM');
      reject(new Error(`Command timed out after ${timeout}ms`));
    }, timeout);

    proc.on('close', (code) => {
      clearTimeout(timer);
      resolve({ stdout, stderr, exitCode: code ?? 1 });
    });

    proc.on('error', (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

// ============================================================================
// Output Formatting
// ============================================================================

function formatMarkdownTable(results: BenchResult[]): string {
  const lines: string[] = [];

  lines.push('# Benchmark Results');
  lines.push('');
  lines.push(`Generated: ${new Date().toISOString()}`);
  lines.push('');

  // Summary table
  lines.push('## Summary');
  lines.push('');
  lines.push(
    '| Scenario | Run ID | Outcome | Stop Reason | Duration | Milestones | Workers (C/X) | Verify (A/R) | Ticks | Reliability |'
  );
  lines.push(
    '|----------|--------|---------|-------------|----------|------------|---------------|--------------|-------|-------------|'
  );

  for (const r of results) {
    const duration = r.durationSeconds
      ? formatDuration(r.durationSeconds)
      : '-';
    const milestones = `${r.milestonesCompleted}/${r.milestonesTotal ?? '?'}`;
    const workers = `${r.workerClaude}/${r.workerCodex}`;
    const verify = `${r.verifyAttempts}/${r.verifyRetries}`;
    const reliability = formatReliability(r);

    lines.push(
      `| ${r.scenario} | ${r.runId ?? '-'} | ${r.outcome} | ${r.stopReason ?? '-'} | ${duration} | ${milestones} | ${workers} | ${verify} | ${r.ticksUsed} | ${reliability} |`
    );
  }

  lines.push('');

  // Diagnosis Summary (for stopped runs)
  const stoppedRuns = results.filter(
    (r) => r.diagnosis && r.outcome !== 'complete'
  );
  if (stoppedRuns.length > 0) {
    lines.push('## Diagnosis Summary');
    lines.push('');

    // Count by diagnosis category
    const diagnosisCounts: Record<string, number> = {};
    for (const r of stoppedRuns) {
      if (r.diagnosis) {
        const key = r.diagnosis.primary;
        diagnosisCounts[key] = (diagnosisCounts[key] || 0) + 1;
      }
    }

    lines.push('### Stop Diagnoses by Category');
    lines.push('');
    lines.push('| Diagnosis | Count | Scenarios |');
    lines.push('|-----------|-------|-----------|');

    for (const [diag, count] of Object.entries(diagnosisCounts).sort(
      (a, b) => b[1] - a[1]
    )) {
      const scenarios = stoppedRuns
        .filter((r) => r.diagnosis?.primary === diag)
        .map((r) => r.scenario)
        .join(', ');
      lines.push(`| ${diag} | ${count} | ${scenarios} |`);
    }
    lines.push('');

    // Per-run diagnosis details
    lines.push('### Per-Run Diagnosis');
    lines.push('');
    lines.push('| Scenario | Run ID | Diagnosis | Confidence | Next Action |');
    lines.push('|----------|--------|-----------|------------|-------------|');

    for (const r of stoppedRuns) {
      if (r.diagnosis) {
        const nextAction = r.diagnosis.nextAction
          ? `\`${r.diagnosis.nextAction.slice(0, 40)}...\``
          : '-';
        lines.push(
          `| ${r.scenario} | ${r.runId ?? '-'} | ${r.diagnosis.primary} | ${Math.round(r.diagnosis.confidence * 100)}% | ${nextAction} |`
        );
      }
    }
    lines.push('');
  }

  // Detailed breakdown
  lines.push('## Detailed Results');
  lines.push('');

  for (const r of results) {
    lines.push(`### ${r.scenario}`);
    lines.push('');
    lines.push(`- **Run ID**: ${r.runId ?? 'N/A'}`);
    lines.push(`- **Outcome**: ${r.outcome}`);
    lines.push(`- **Stop Reason**: ${r.stopReason ?? 'N/A'}`);
    if (r.diagnosis) {
      lines.push(
        `- **Diagnosis**: ${r.diagnosis.primary} (${Math.round(r.diagnosis.confidence * 100)}%)`
      );
    }
    lines.push(
      `- **Duration**: ${r.durationSeconds ? formatDuration(r.durationSeconds) : 'N/A'}`
    );
    lines.push(
      `- **Milestones**: ${r.milestonesCompleted}/${r.milestonesTotal ?? '?'}`
    );
    lines.push(
      `- **Worker Calls**: Claude=${r.workerClaude}, Codex=${r.workerCodex}`
    );
    lines.push(
      `- **Verification**: ${r.verifyAttempts} attempts, ${r.verifyRetries} retries, ${r.verifyDurationSeconds}s`
    );
    lines.push(`- **Ticks Used**: ${r.ticksUsed} (max hit: ${r.maxTicksHit})`);
    lines.push(
      `- **Reliability**: infra_retries=${r.infraRetries}, fallbacks=${r.fallbackCount}, stalls=${r.stallsTriggered}`
    );
    if (r.error) {
      lines.push(`- **Error**: ${r.error}`);
    }
    lines.push('');
  }

  // CSV for easy import
  lines.push('## CSV Export');
  lines.push('');
  lines.push('```csv');
  lines.push(
    'scenario,run_id,outcome,stop_reason,diagnosis,diagnosis_confidence,duration_s,milestones_done,milestones_total,claude_calls,codex_calls,verify_attempts,verify_retries,verify_duration_s,ticks_used,max_ticks_hit,infra_retries,fallback_count,stalls'
  );
  for (const r of results) {
    lines.push(
      [
        r.scenario,
        r.runId ?? '',
        r.outcome,
        r.stopReason ?? '',
        r.diagnosis?.primary ?? '',
        r.diagnosis?.confidence ?? '',
        r.durationSeconds ?? '',
        r.milestonesCompleted,
        r.milestonesTotal ?? '',
        r.workerClaude,
        r.workerCodex,
        r.verifyAttempts,
        r.verifyRetries,
        r.verifyDurationSeconds,
        r.ticksUsed,
        r.maxTicksHit,
        r.infraRetries,
        r.fallbackCount,
        r.stallsTriggered,
      ].join(',')
    );
  }
  lines.push('```');

  return lines.join('\n');
}

function formatDuration(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  if (minutes < 60) {
    return remainingSeconds > 0 ? `${minutes}m${remainingSeconds}s` : `${minutes}m`;
  }
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  return remainingMinutes > 0 ? `${hours}h${remainingMinutes}m` : `${hours}h`;
}

function formatReliability(r: BenchResult): string {
  const issues: string[] = [];
  if (r.infraRetries > 0) issues.push(`infra:${r.infraRetries}`);
  if (r.fallbackCount > 0) issues.push(`fb:${r.fallbackCount}`);
  if (r.stallsTriggered > 0) issues.push(`stall:${r.stallsTriggered}`);
  if (r.maxTicksHit) issues.push('⏱️');
  return issues.length > 0 ? issues.join(' ') : '✓';
}

// ============================================================================
// Scenario Loading
// ============================================================================

function loadScenariosFromConfig(configPath: string): BenchScenario[] {
  if (!fs.existsSync(configPath)) {
    throw new Error(`Config file not found: ${configPath}`);
  }

  const raw = fs.readFileSync(configPath, 'utf-8');
  const config = JSON.parse(raw) as { scenarios?: BenchScenario[] };

  if (!config.scenarios || !Array.isArray(config.scenarios)) {
    throw new Error('Config file must have a "scenarios" array');
  }

  // Validate and provide defaults
  return config.scenarios.map((s, i) => ({
    name: s.name || `scenario-${i}`,
    task: s.task,
    repo: s.repo,
    time: s.time ?? 15,
    maxTicks: s.maxTicks ?? 25,
    worktree: s.worktree ?? true,
    env: s.env,
    flags: s.flags,
  }));
}

// ============================================================================
// Config Validation (tier0 sanity check)
// ============================================================================

interface Tier0ValidationResult {
  ok: boolean;
  warnings: string[];
  tier0Commands: string[];
}

/**
 * Validates that the agent config's tier0 contains essential verification commands.
 * Returns warnings if tier0 is incomplete.
 */
function validateTier0Config(scenario: BenchScenario): Tier0ValidationResult {
  const result: Tier0ValidationResult = {
    ok: true,
    warnings: [],
    tier0Commands: [],
  };

  // Determine config path
  const configPath = scenario.config
    ? scenario.config
    : path.join(scenario.repo, 'agent.config.json');

  if (!fs.existsSync(configPath)) {
    // No config file - can't validate, assume ok
    result.warnings.push(`Config not found: ${configPath} (skipping tier0 validation)`);
    return result;
  }

  try {
    const raw = fs.readFileSync(configPath, 'utf-8');
    const config = JSON.parse(raw) as {
      verification?: {
        tier0?: string[];
        tier1?: string[];
      };
    };

    const tier0 = config.verification?.tier0 ?? [];
    result.tier0Commands = tier0;

    // Essential commands that should be in tier0 for reliable verification
    const essentialPatterns = [
      { pattern: /lint/i, name: 'lint' },
      { pattern: /test/i, name: 'test' },
      { pattern: /typecheck|tsc/i, name: 'typecheck' },
    ];

    const missingEssentials: string[] = [];
    for (const essential of essentialPatterns) {
      const found = tier0.some(cmd => essential.pattern.test(cmd));
      if (!found) {
        // Check if it's in tier1 instead (common misconfiguration)
        const tier1 = config.verification?.tier1 ?? [];
        const inTier1 = tier1.some(cmd => essential.pattern.test(cmd));
        if (inTier1) {
          missingEssentials.push(`${essential.name} (in tier1, should be in tier0)`);
        }
      }
    }

    if (missingEssentials.length > 0) {
      result.ok = false;
      result.warnings.push(
        `tier0 incomplete: missing ${missingEssentials.join(', ')}`
      );
    }

    // Warn if tier0 is empty
    if (tier0.length === 0) {
      result.ok = false;
      result.warnings.push('tier0 is empty - no verification will run');
    }

  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    result.warnings.push(`Failed to parse config: ${msg}`);
  }

  return result;
}

function resolveScenarios(options: BenchOptions): BenchScenario[] {
  // Priority: config file > preset > default (minimal)
  if (options.configPath) {
    console.log(`Loading scenarios from: ${options.configPath}`);
    return loadScenariosFromConfig(options.configPath);
  }

  if (options.preset) {
    const preset = PRESETS[options.preset.toLowerCase()];
    if (!preset) {
      console.error(
        `Unknown preset: ${options.preset}. Available: ${Object.keys(PRESETS).join(', ')}`
      );
      process.exit(1);
    }
    console.log(`Using preset: ${options.preset}`);
    return preset;
  }

  console.log('Using default preset: minimal');
  return DEFAULT_SCENARIOS;
}

function expandScenariosWithRepeat(
  scenarios: BenchScenario[],
  repeat: number
): BenchScenario[] {
  if (repeat <= 1) return scenarios;

  const expanded: BenchScenario[] = [];
  for (let r = 1; r <= repeat; r++) {
    for (const s of scenarios) {
      expanded.push({
        ...s,
        name: `${s.name}-r${r}`,
      });
    }
  }
  return expanded;
}

// ============================================================================
// Main
// ============================================================================

async function main(): Promise<void> {
  const options = parseArgs();

  console.log('Benchmark Harness');
  console.log('=================');
  console.log(`Dry run: ${options.dryRun}`);
  console.log(`Output: ${options.outputPath}`);
  if (options.repeat > 1) {
    console.log(`Repeat: ${options.repeat}x per scenario`);
  }

  // Load scenarios
  let scenarios = resolveScenarios(options);

  // Apply repeat
  scenarios = expandScenariosWithRepeat(scenarios, options.repeat);

  // Apply filter
  if (options.scenarioFilter) {
    scenarios = scenarios.filter((s) =>
      s.name.toLowerCase().includes(options.scenarioFilter!.toLowerCase())
    );
    console.log(
      `Filtered to ${scenarios.length} scenarios matching "${options.scenarioFilter}"`
    );
  }

  if (scenarios.length === 0) {
    console.error('No scenarios to run');
    process.exit(1);
  }

  console.log(`\nScenarios to run (${scenarios.length}):`);
  for (const s of scenarios) {
    console.log(`  - ${s.name}`);
  }

  // Run scenarios
  const results: BenchResult[] = [];

  if (options.parallel) {
    console.log('\nRunning scenarios in parallel...');
    const promises = scenarios.map((s) => runScenario(s, options.dryRun));
    results.push(...(await Promise.all(promises)));
  } else {
    console.log('\nRunning scenarios sequentially...');
    for (const scenario of scenarios) {
      const result = await runScenario(scenario, options.dryRun);
      results.push(result);
    }
  }

  // Generate output
  const markdown = formatMarkdownTable(results);

  if (!options.dryRun) {
    fs.writeFileSync(options.outputPath, markdown, 'utf-8');
    console.log(`\nResults written to: ${options.outputPath}`);
  }

  // Print summary to console
  console.log('\n' + markdown);

  // Exit code based on outcomes
  const failures = results.filter(
    (r) => r.outcome === 'unknown' || (r.error !== undefined && r.outcome !== 'skipped')
  );
  const skipped = results.filter((r) => r.outcome === 'skipped');

  if (skipped.length > 0) {
    console.error(`\n⚠️  ${skipped.length} scenario(s) skipped due to config issues`);
  }

  if (failures.length > 0) {
    console.error(`\n❌ ${failures.length} scenario(s) failed`);
    process.exit(1);
  }

  if (skipped.length > 0) {
    console.error('\n⚠️  Some scenarios were skipped. Fix config issues and re-run.');
    process.exit(2); // Different exit code for skipped
  }
}

main().catch((err) => {
  console.error('Benchmark harness failed:', err);
  process.exit(1);
});
