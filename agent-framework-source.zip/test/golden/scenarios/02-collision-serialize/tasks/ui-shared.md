# Update shared formatUser for UI

Update the formatUser function in shared.ts to include a prefix parameter.
