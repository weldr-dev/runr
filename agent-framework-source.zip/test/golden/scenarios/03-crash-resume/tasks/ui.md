# Add UI component

Add a simple loading spinner component to the UI module.
