# Summary

Run stopped due to guard violations.

Guard reasons:
- dirty_worktree
- scope_violation

Scope violations:
- test/

Lockfile violations:
- None

Binary checks:
- claude: --version
- codex: --version

Ping results:
- claude: OK (5ms)
- codex: OK (5ms)