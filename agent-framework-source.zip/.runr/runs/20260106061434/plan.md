{
  "milestones": [
    {
      "goal": "Run focused test suite and confirm all 30 tests pass with no regressions",
      "files_expected": [
        ".runr/tasks/verify-run-receipt-v1.md"
      ],
      "done_checks": [
        "npx vitest run src/receipt/__tests__ src/tasks/__tests__ exits 0",
        "Output shows 30 passed",
        "receipt.json structure tests pass (base_sha, checkpoint_sha, artifacts_written)",
        "Compression threshold tests pass (50KB, 2000 lines, 100 files)",
        "transcript.meta.json creation test passes",
        "Task allowlist_add parsing tests pass (frontmatter + body)",
        "Verification tier normalization test passes (TIER1 → tier1)",
        "Console output format test passes (checkpoint + next action)"
      ],
      "risk_level": "low"
    }
  ],
  "risk_map": [
    "Risk 1: Tests may fail due to environment issues - mitigation: run in clean worktree",
    "Risk 2: Test count may have changed - mitigation: verify actual count matches expected"
  ],
  "do_not_touch": [
    "src/receipt/writer.ts",
    "src/tasks/task-metadata.ts",
    "src/receipt/__tests__/writer.test.ts",
    "src/tasks/__tests__/task-metadata.test.ts"
  ]
}