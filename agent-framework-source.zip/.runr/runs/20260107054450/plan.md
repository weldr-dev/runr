{
  "milestones": [
    {
      "goal": "Enhance conflict output format to match exact spec with recovery state checkmarks",
      "files_expected": [
        "src/commands/submit.ts"
      ],
      "done_checks": [
        "Output shows 'Cherry-pick conflict detected.' header",
        "Output shows checkpoint SHA (full, not abbreviated)",
        "Output shows target branch name",
        "Output lists conflicted files with bullet points",
        "Output shows recovery state with checkmarks (✓ Branch restored, ✓ Working tree is clean)",
        "Recovery commands are copy-paste ready with actual values"
      ],
      "risk_level": "medium"
    },
    {
      "goal": "Enhance timeline event payload with recovery metadata and suggested commands",
      "files_expected": [
        "src/commands/submit.ts"
      ],
      "done_checks": [
        "submit_conflict event includes recovery_branch field",
        "submit_conflict event includes recovery_state field ('clean' or 'dirty')",
        "submit_conflict event includes suggested_commands array with git commands",
        "All existing payload fields (target_branch, checkpoint_sha, conflicted_files) preserved"
      ],
      "risk_level": "low"
    },
    {
      "goal": "Add assertion checks after conflict cleanup to enforce invariants",
      "files_expected": [
        "src/commands/submit.ts"
      ],
      "done_checks": [
        "Assert current branch equals starting branch after cleanup",
        "Assert working tree is clean after cleanup",
        "Assertions log warnings if invariants fail rather than throwing",
        "Invariant failures are reflected in output messaging"
      ],
      "risk_level": "medium"
    },
    {
      "goal": "Make CHANGELOG tip conditional based on feature detection and file changes",
      "files_expected": [
        "src/commands/submit.ts"
      ],
      "done_checks": [
        "CHANGELOG tip only shows when CHANGELOG.md exists in repo",
        "CHANGELOG tip only shows when checkpoint doesn't already modify CHANGELOG.md",
        "CHANGELOG tip suppressed when directly in conflicted files",
        "Tip text suggests considering updating CHANGELOG.md"
      ],
      "risk_level": "low"
    },
    {
      "goal": "Add dry-run conflict detection that reports potential conflicts without changes",
      "files_expected": [
        "src/commands/submit.ts"
      ],
      "done_checks": [
        "Dry-run detects if cherry-pick would cause conflict",
        "Reports which files would conflict in dry-run output",
        "Makes NO changes to branch, tree, or timeline in dry-run",
        "Distinguishes between 'would succeed' and 'would conflict' cases"
      ],
      "risk_level": "high"
    },
    {
      "goal": "Create acceptance test suite for submit conflict handling",
      "files_expected": [
        "test/acceptance/submit-conflict.test.ts"
      ],
      "done_checks": [
        "Test verifies clean state restoration after conflict",
        "Test verifies recovery commands in output",
        "Test verifies conflicted files are listed",
        "Test verifies timeline event has all required fields",
        "Test verifies branch is always restored"
      ],
      "risk_level": "medium"
    }
  ],
  "risk_map": [
    "Risk 1: Dry-run conflict detection may not be 100% accurate (git merge-tree limitations) - mitigate with documentation",
    "Risk 2: Edge cases in branch restoration (detached HEAD, force operations) - mitigate with try-catch and warnings",
    "Risk 3: Tests may be flaky due to git timing - mitigate with proper async handling and cleanup"
  ],
  "do_not_touch": [
    "src/store/run-store.ts",
    "src/config/load.ts",
    "src/config/schema.ts"
  ]
}