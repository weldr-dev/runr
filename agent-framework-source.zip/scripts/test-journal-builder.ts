#!/usr/bin/env tsx
/**
 * Dev script to test journal builder on a real run
 *
 * Usage: tsx scripts/test-journal-builder.ts <run_id> [--repo <path>]
 */

import { buildJournal } from '../src/journal/builder.js';

const args = process.argv.slice(2);
const runId = args[0];
const repoIndex = args.indexOf('--repo');
const repo = repoIndex >= 0 ? args[repoIndex + 1] : process.cwd();

if (!runId) {
  console.error('Usage: tsx scripts/test-journal-builder.ts <run_id> [--repo <path>]');
  process.exit(1);
}

(async () => {
  try {
    const journal = await buildJournal(runId, repo);
    console.log(JSON.stringify(journal, null, 2));
  } catch (err) {
    console.error('ERROR:', err);
    process.exit(1);
  }
})();
